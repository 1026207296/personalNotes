$(function () {
    // loading 区域
    let loadingRender = (function () {
        let $wrap=$(".wrap"),
        $loading=$wrap.find(".loading"),
        $progressWrap=$loading.find(".progressWrap");
        $progressIn=$progressWrap.children(".progressIn");
        ary = ['phone-bg.jpg', 'phone-listen.png', 'phone-key.png', 'phone-logo.png', 'phone-name.png', 'message-head1.png', 'message-head2.png', 'message-keyboard.png', 'cube-bg.jpg', 'cube-img1.png', 'cube-img2.png', 'cube-img3.png', 'cube-img4.png', 'cube-img5.png', 'cube-img6.png', 'cube-tip.png', 'menu-icon.png', 'concat-address.png', 'concat-icon1.png', 'concat-icon2.png', 'course-icon1.png', 'course-icon2.png', 'course-icon3.png', 'course-icon4.png', 'course-icon5.png', 'course-icon6.png', 'course-icon7.png', 'course-pocket.png', 'school-bot1.png', 'school-bot2.png', 'school-img1.jpg', 'school-img2.jpg', 'school-img3.jpg', 'teacher-title.png', 'zf-detailsReturn.png', 'zf-jobTable.png', 'zf-teacher1.png', 'zf-teacher2.png', 'zf-teacher3.jpg', 'zf-teacher4.png', 'zf-teacher5.png', 'zf-teacher6.png'],
        //记录已经加载图片的张数
        n=0,
        imgTotal=ary.length,
        deayTimer=null;
        //进度条加载的业务逻辑
        function progressLoad(){
             ary.forEach(function(item,i){
                var img=new Image();
                img.src=`images/${item}`;
                // 当图片加载成功之后
                img.onload=function(){
                    n++;
                    $progressIn.css("width",`${n/imgTotal*100}%`);
                    // 说明已经加载完毕
                    if(n>=imgTotal){
                        clearTimeout(deayTimer);
                        deayTimer=null;
                        $progressIn.css("width",'100%');
                        // 加载成功之后做的事情
                        done();
                    }
                }
             });
             // 如果说已经到十秒了，还没有加载完毕，温馨提示
             deayTimer=setTimeout(function(){
                if(n/imgTotal<1){
                    alert("您当前的网络较慢，请稍后再试");
                } 
             },10000)

        }
        // 成功之后要做的事情
        function done(){
            $loading.fadeOut();
            $loading.remove();
        }

        return {
            // 初始化函数
            init: function () {
               //让当前区域显示
               $loading.show();
               // 进度条的逻辑
               progressLoad();
            }
        }
    })();
   //loadingRender.init();
   // phone 区域
   let phoneRender=(function(){
       let $phone=$(".phone"),
           $listenWrap=$phone.find(".listenWrap"),
           $answerWrap=$phone.find(".answerWrap"),
           $redMark=$answerWrap.find(".redMark"),
           $bellAudio=$phone.find("#bellAudio"),
           $sayAudio=$phone.find("#sayAudio"),
           $telMark=$listenWrap.find(".telMark"),
           $time=$phone.find(".time"),
           timer=null,
           currentTime=null,
           duration=null;
           // 点击绿色电话的操作
           function greenTelFn(){
              // 让电话铃声暂停
              $bellAudio[0].pause();
              // 让打电话的区域消失
              $listenWrap.hide();
              // 让键盘区域从下往上出现
              $answerWrap.css("transform","translateX(-50%) translateY(0)");
              // 让自我介绍的铃声响起
              $sayAudio[0].play();
              // 初始化时间
              initTime();
              timer=setInterval(function(){
                initTime();
              }, 1000);
           };
           // 处理时间
           function forMatTime(value){
               var minutes=Math.floor(value/60);
               var seconds=Math.floor(value-minutes*60);
               minutes=minutes<10?"0"+minutes:minutes;
               seconds=seconds<10?"0"+seconds:seconds;
               return   minutes+":"+seconds;
           }
           // 初始化自我介绍的说话时间
           function initTime (){
                currentTime=$sayAudio[0].currentTime;
                duration=$sayAudio[0].duration;
                console.log(currentTime,duration);
                $time.html(forMatTime(currentTime));
                //已播放的时长和总时长，如果相等了，说明播放完毕
                if(currentTime==duration){
                    // 执行成功函数
                    done();
                }
           }
           function done(){
               //清除定时器
               clearInterval(timer);
               timer=null;
               $sayAudio[0].pause();
               $phone.fadeOut();
               $phone.remove();
           }
       return {
           init:function(){
              //此区域显示
              $phone.show();
              // 电话铃声响起
              $bellAudio[0].play();
              // 控制声音的
              $bellAudio[0].volume=0.1;
              // 点击绿色电话的逻辑
              $telMark.click(function(){
                  greenTelFn();
              });
              // 给红色电话绑定点击事件
              $redMark.click(function(){
                done();
              })
           }
       }
   })();
   //phoneRender.init();

   //message 区域

   let messageRender=(function(){
      let $message=$(".message"),
          $talkWrap=$message.find(".talkWrap"),
          $lis=$talkWrap.find("li"),
          $keybordWrap=$message.find(".keybordWrap"),
          $btn=$keybordWrap.find(".btn"),
          $keywords=$keybordWrap.find(".keywords"),
          $audio=$message.find("audio"),
          str="本小姐考虑考虑~",
          //记录li的索引
          n=-1,
          interval=1000,
          timer=null,
          h=0;

        function liShow(){
            timer=setInterval(function(){
                 n++;
                 if(n==2){
                    //说明前两条li已经播放完毕，停止，让键盘从下往上出来
                    clearInterval(timer);
                    timer=null;
                    $keybordWrap.css("transform","translateY(0)");
                    // 打字效果
                     writeFn();
                    return;
                 }
                 if(n>3){
                  // 当li的索引值大于3的时候，让整个 $talkWrap向上移动
                  h+=$talkWrap.find("li").eq(n).outerHeight();
                  $talkWrap.css("transform",`translateY(${-h}px)`);
                 }
                 if(n>$talkWrap.find("li").length-1){
                     // 说明已经结束;
                     done();
                     return;
                 }
                 $talkWrap.find("li").eq(n).addClass("current");
            },interval)
           
        }
        //打字
        function writeFn(){
            let n=-1;
            var timer2=setInterval(function(){
                n++;
                $keywords.focus();
                //说明已经写完了
                if(n>str.length-1){
                   clearInterval(timer2);
                   timer2=null;
                   //让发送按钮出现
                   $btn.show();
                   return;
                }
                var value= $keywords.val()+str[n];
                $keywords.val(value);

            },500)
           
        }
        // 发送按钮
        function sendbtn(){
            //让input框里面的文字变成空的
            $keywords.val("");
            // 让键盘从上往下去
            $keybordWrap.css("transform","translateY(4.2rem)");
            // 把input 框中的文字手动生成了li插入到$keybordWrap
            $talkWrap.find("li").eq(1).after(`<li class="self me">
            <img class="photo" src="images/message-head1.png" alt="">
             <p>${str}</p>
         </li>`);
           // 手动给第第三个li添加一个动态效果
          $talkWrap.find(".me").addClass("current");
            // 让li 继续播放
            liShow();
        }
        // 成功函数
        function done(){
            clearInterval(timer);
            timer=null;
            $audio[0].pause();
            $message.fadeOut();
            $message.remove();
            // setTimeout(function(){
            //     $message.remove();
            // },1000)
            
        }
       return {
           init:function(){
                //让此区域显示
                $message.show();
                // 让音乐响起
                $audio[0].play();
                // 让li展示
                liShow();
                // 给发送按钮绑定事件
                $btn.click(function(){
                    sendbtn();
                })
           }
       }
   })();

   messageRender.init();







})