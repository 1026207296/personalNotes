var ary=[1,2,3];
var ary2=[4,5];
ary.reduce(function(pre,next){
   console.log(pre)
},...ary2)