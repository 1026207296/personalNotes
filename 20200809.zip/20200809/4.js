import instance2 from "./api/instance2";

// instance2.get('');