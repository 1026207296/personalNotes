var a={}, b={n:'1'}, c={m:'2'};  
a[b]='珠峰';
a[c]='培训';  
console.log(a[b]);


/* 
{
 {n:'1'}:"珠峰"   
}

{
  "[object Object]":"珠峰"  
}

{
  "[object Object]":"培训"  
}


*/