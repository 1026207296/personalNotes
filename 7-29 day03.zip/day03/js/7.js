
name="lili";
age=18;
function fn2(){
   console.log("会js");
}

name="dawei";
age=30;
function fn(){
    console.log("会java")
}

/* 丽丽 */
var obj1={
    name:"lili",
    age:18,
    fn:function(){
        console.log("会js")
    }
}
console.log(obj1.name);
console.log(obj2.name);

var obj2={
    name:"dawei",
    age:30,
    fn:function(){
        console.log("会java")
    }
}

