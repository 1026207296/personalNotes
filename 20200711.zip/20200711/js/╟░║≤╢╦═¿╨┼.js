// http://www.zhufeng.cn/index.html?lx=0&from=http://www.baidu.com/
// 把一个URL中的局部信息进行编译处理
// =>处理特殊字符
// =>处理中文汉字
// =>...


/* // encodeURI / decodeURI：对中文汉字（或者空格等）编码，对一些URL地址符号不处理
// encodeURIComponent / decodeURIComponent：会把特殊字符也编码

let url = "http://www.zhufeng.cn/index.html?lx=珠峰&from=http://www.baidu.com/";
// console.log(encodeURI(url));
// console.log(encodeURIComponent(url));

url = `http://www.zhufeng.cn/index.html?lx=${encodeURIComponent('珠峰')}&from=${encodeURIComponent('http://www.baidu.com/')}`;

console.log(url); */


/*
 * TCP三次握手：客户端和服务器之间建立连接
 *    seq：序号
 *    ack：确认号
 *    
 *    标志位：ASK/SYN/FIN  PSH/URG/RST
 *    ACK：确认序号有效
 *    SYN：发送一个新的链接
 *    FIN：释放一个连接
 * 
 * TCP四次挥手：断开链接
 *    
 * HTTP1.0：发送一个请求建立TCP链接，当服务器把消息返回后，会断开TCP链接
 * HTTP1.1：Connection: keep-alive建立长链接
 * HTTP2.0：在1.1的基础上，允许一个通道中并发多个请求
 */

/*
 * 前端性能优化 CRP
 *    【页面底层渲染机制】
 *       1. 标签语义化和避免结构深层次嵌套（不仅有利于SEO优化，而且加快DOM树的构建）
 *       2. 样式代码少的情况下，写成内嵌式（减少HTTP请求）；多的情况下，我们最好基于link外链式导入样式，避免使用@import导入式（因为它会阻碍GUI的渲染）；并且把加载CSS的代码写在HEAD中（这样在构建DOM树的时候，同时也去加载CSS了，可以让CSSOM树尽快解析出来）；
 *       3. 避免阻塞的JS加载，对于script尽可能使用defer/async，并且放在页面的底部
 *       4. 减少DOM的回流和重绘（...）
 * 
 *    【网络请求机制】
 *       1. 每一次DNS解析时间预计在20~120毫秒，所以这方面可以着手优化：尽可能减少DNS的解析次数，以及使用DNS Prefetch（DNS预解析）
 *       2. 尽可能使用Connection:keep-alive长连接，减少TCP三次握手的消耗（服务器设定）
 *       3. （HTTP具备并发性，一次能同时处理的请求在6~7个左右）尽可能减少HTTP请求的次数以及请求资源文件的大小
 *          ->资源合并/压缩（基于webpack把css/js等资源打包成为一个）
 *          ->服务器开启GZIP压缩（可以把资源压缩60%左右）
 *          ->图片上的优化处理：字体图标、雪碧图、BASE64
 *       4. 加载CDN资源（烧钱）
 *       5. 资源和数据的缓存（第一次从服务器拿到信息，后期只要在有效期限内，直接从客户端本地获取信息即可，无需再向服务器发送请求拿资源）
 *          =>资源文件的缓存（强缓存和协商缓存）
 *          =>数据缓存（本地存储localStorage或者本地数据库存储[不常用]）
 *          =>H5中的Manifest离线存储[不常用]
 *          ......
 * 
 *    【其它层面的优化】
 *       1. 提高页面第一次渲染解析的效率
 *         =>所有图片资源的延迟加载
 *         =>默认先只加载首屏（或者第二屏幕）的数据，页面滚动过程中，再去加载其它屏幕的数据（或者再去渲染其它屏幕的结构和内容 =>由JS动态渲染页面）
 *         =>为了防止等待间的白屏效果，我们设置LOADONG或者骨架屏（客户端骨架屏或者服务器骨架屏技术）
 *       2. 代码上的优化(CSS/JS)
 *         =>内存优化和防止内存泄漏
 *         =>封装和设计模式
 *         =>避免一些消耗性能代码的使用：with/eval
 * 
 *       3. webpack打包的优化
 *       4. vue/react中的优化技巧
 *       5. 安全上的优化
 */