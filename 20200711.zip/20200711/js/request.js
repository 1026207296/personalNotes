/* 
fetch('./data.json', {
	// 控制携带资源凭证(例如cookie)  
	// same-origin同源才可以  omit都拒绝  include非同源策略下也允许
	credentials: 'include',
	// 自定义请求头信息
	headers: {},
	// 设置请求方式
	method: 'GET',
	// POST系列请求中，基于请求主体传递给服务器的信息
	// body: ''
}).then(response => {
	console.log(response);
	/!*
	 * 是Response类的一个实例
	 *     body响应主体信息，想要获取信息，需要调用Response.prototype上的各个方法（json/arrayBuffer/blob/text...）
	 *     status/statusText 状态码和状态码的描述
	 * 
	 * fetch不论请求回来的网络状态码是多少，都认为是成功的（它的成功是只要能从服务器拿到信息就算成功，只有向服务器发送请求，服务器没有给任何的反馈 [例如断网] 才算失败）
	 *!/
	// 获取响应头信息：服务器端获取的响应头信息是Headers类的一个实例，基于Headers.prototype上的各种方法，可以获取指定的信息
	// console.log(response.headers.get('Date'));
}); 
*/
(function () {
	const _getReg = /^(GET|HEAD|DELETE|OPTIONS)$/i;

	// 合并参数配置项
	function _initDefaults(options) {
		let headers = options.headers;
		if (headers && typeof headers === "object") {
			request.defaults.headers = Object.assign(
				request.defaults.headers,
				headers
			);
			delete options.headers;
		}
		return Object.assign(request.defaults, options);
	}

	// 处理URL
	function _handleURL(options) {
		let {
			baseURL,
			url,
			method,
			body
		} = options;
		url = baseURL + url;
		if (_getReg.test(method) && body && typeof body === "object") {
			let str = ``;
			Object.keys(body).forEach(key => {
				// 我们不对某一项是对象做处理
				str += `&${key}=${body[key]}`;
			});
			body = str.substring(1);
			url += `${url.includes('?')?'&':'?'}${body}`;
		}
		return url;
	}

	// 处理OPTIONS
	function _handleOptions(options) {
		let config = {
			credentials: options.credentials,
			method: options.method,
			headers: options.headers
		};
		if (!_getReg.test(options.method)) {
			// POST系列请求
			options.body = options.transformRequest(options.body);
			config.body = options.body;
		}
		return config;
	}

	// 发送请求
	function request(options = {}) {
		options = _initDefaults(options);
		return fetch(_handleURL(options), _handleOptions(options))
			.then(response => {
				let status = response.status;

				// 状态码以2开头我们认为是成功的，否则都可以按照失败处理
				if (status >= 200 && status < 300) {
					// 并且按照配置项中指定的响应数据类型，把从服务器获取的响应主体信息处理为对应的类型返回给用户
					let responseType = options.responseType,
						result = response.json();
					switch (responseType.toLowerCase()) {
						case 'text':
							result = response.text();
							break;
						case 'blob':
							result = response.blob();
							break;
						case 'arraybuffer':
							result = response.arrayBuffer();
							break;
					}
					return result;
				}

				// 失败的状态
				switch (status) {
					case 401:
						break;
					case 403:
						break;
					case 404:
						break;
					case 500:
						break;
				}
				return Promise.reject(response);
			})
			.catch(reason => {
				// 服务器没有返回任何的信息
				if (!window.navigator.onLine) {
					// 断网处理
				}
				return Promise.reject(reason);
			});
	}

	// 默认参数配置项
	request.defaults = {
		baseURL: '',
		url: '',
		credentials: 'include',
		method: 'GET',
		// 如果GET系请求，则把BODY中的信息拼接到URL末尾，如果是POST系，则基于FETCH请求的时候，根据BODY把其传递给服务器
		body: {},
		headers: {
			'Content-Type': 'application/json;charset=UTF-8'
		},
		// POST请求下，默认会把BODY中的数据变为JSON字符串传递给服务器
		transformRequest: data => JSON.stringify(data),
		responseType: 'json'
	};

	// 暴露API
	window.request = request;
	if (typeof module === "object" && typeof module.exports === "object") {
		module.exports = request;
	}
})();

/* 导入之前再做一些默认的配置 */
request.defaults.baseURL = "";
request.defaults.headers['Content-Type'] = "application/x-www-form-urlencoded";

// 可能需要设置TOKEN
let token = localStorage.getItem('token');
token && (request.defaults.headers['Authorization'] = token);

request.defaults.transformRequest = data => {
	if (data && typeof data === "object") {
		let str = ``;
		Object.keys(data).forEach(key => {
			// 我们不对某一项是对象做处理
			str += `&${key}=${data[key]}`;
		});
		data = str.substring(1);
	}
	return data;
};