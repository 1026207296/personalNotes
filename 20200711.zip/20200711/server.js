/*-CREATE SERVER-*/
const express = require('express'),
	app = express();
app.listen(1001, () => {
	console.log(`THE WEB SERVICE IS CREATED SUCCESSFULLY AND IS LISTENING TO THE PORT：1001`);
});

/*-MIDDLE WARE-*/
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({
	extended: false
}));

/*-API-*/
/* JSONP */
/* app.get('/list', (req, res) => {
	// req.query 问号传递的参数信息
	// callback存储的是一个函数名（客户端全局的）
	let {
		callback
	} = req.query;

	// 准备返回的数据
	let result = {
		code: 0,
		data: [10, 20]
	};
	let str = `${callback}(${JSON.stringify(result)})`;
	res.send(str);
});
 */

/* CORS：服务器端设置（设置允许源） */
app.use((req, res, next) => {
	// 设置允许源
	// * 允许所有源（不安全/不能携带资源凭证）
	// 设置单一源（安全/也可以携带资源凭证/只能是单一一个源）
	// 可以动态设置多个源：每一次请求都会走这个中间件，我们首先设置一个白名单，如果当前客户端请求的源在白名单中，我们把Allow-Origin动态设置为当前这个源
	/* let safeList = [
		"http://127.0.0.1:5500"
	]; */
	res.header("Access-Control-Allow-Origin", "http://127.0.0.1:5500");
	res.header("Access-Control-Allow-Credentials", true);

	/* res.header("Access-Control-Allow-Headers", "Content-Type,....");
	res.header("Access-Control-Allow-Methods", "GET,..."); */

	// 试探请求：在CORS跨域请求中，首先浏览器会自己发送一个试探请求，验证是否可以和服务器跨域通信，服务器返回200，则浏览器继续发送真实的请求
	req.method === 'OPTIONS' ? res.send('CURRENT SERVICES SUPPORT CROSS DOMAIN REQUESTS!') : next();
});

app.get('/list', (req, res) => {
	let result = {
		code: 0,
		data: [10, 20]
	};
	res.send(result);
});


app.post('/add', (req, res) => {
	let result = {
		code: 0
	};
	res.send(result);
});




/* STATIC WEB */
app.use(express.static('./'));