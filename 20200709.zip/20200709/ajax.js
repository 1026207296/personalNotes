/*
 * 封装一款浏览器端使用的AJAX库 
 */
(function () {
	/* 校验是否为浏览器环境 */
	if (typeof window === "undefined" || window.window !== window) {
		throw new Error('The current environment is not a browser environment, please ensure the correctness of the environment!');
	}

	/* 创建AJAX请求类 */
	class MyAJAX {
		constructor(options = {}) {
			this.options = options;
			this.isGET = /^(GET|HEAD|DELETE|OPTIONS)$/i.test(options.method);
			return this.init();
		}
		init() {
			// 请求拦截器是重构CONFIG配置项
			let interceptorsRQ = _ajax.interceptors.request[0],
				interceptorsRS = _ajax.interceptors.response;
			if (typeof interceptorsRQ === "function") {
				this.options = interceptorsRQ(this.options);
			}

			let {
				method,
				headers,
				timeout,
				withCredentials,
				responseType,
				validateStatus
			} = this.options;

			return new Promise((resolve, reject) => {
				let xhr = new XMLHttpRequest;
				xhr.open(method, this.handleURL());

				// 设置自定义请求头信息
				Object.keys(headers).forEach(key => {
					xhr.setRequestHeader(key, headers[key]);
				});

				// 其它的配置信息
				xhr.withCredentials = withCredentials;
				timeout > 0 ? xhr.timeout = timeout : null;

				xhr.onreadystatechange = () => {
					// 校验网络状态码
					let status = xhr.status,
						success = status === 200 ? true : false;
					typeof validateStatus === "function" ? success = validateStatus(status) : null;

					// 网络状态码层面上是成功的
					if (success) {
						if (xhr.readyState === 4) {
							resolve(this.queryInfo(0, xhr));
						}
						return;
					}

					// 失败的
					reject(this.queryInfo(1, xhr));
				};

				// 请求超时或者请求中断都算失败的
				xhr.ontimeout = () => {
					reject(this.queryInfo(1, xhr));
				};
				xhr.onabort = () => {
					reject(this.queryInfo(1, xhr));
				};

				xhr.send(this.handleBODY());
			}).then(...interceptorsRS);
		}
		// 解析URL
		handleURL() {
			let {
				url,
				baseURL,
				params
			} = this.options;
			url = baseURL + url;
			// GET请求需要把PARAMS拼接到URL的末尾（和AXIOS不一样的地方，POST请求下我们不处理PARAMS【相对比较标准的】）
			if (this.isGET && params) {
				if (typeof params === "object") {
					// 如果是一个对象，变为URLENCODED格式
					let str = ``;
					Object.keys(params).forEach(key => {
						// 我们不对某一项是对象做处理
						str += `&${key}=${params[key]}`;
					});
					params = str.substring(1);
				}
				url += `${url.includes('?')?'&':'?'}${params}`;
			}
			return url;
		}
		// 解析请求主体
		handleBODY() {
			let {
				data,
				transformRequest
			} = this.options;
			// POST请求下才对DATA做处理
			if (!this.isGET && data) {
				if (typeof transformRequest === "function") {
					data = transformRequest(data);
				}
				typeof data === "object" ? data = JSON.stringify(data) : null;
				return data;
			}
			return null;
		}
		// 获取失败/成功信息
		queryInfo(lx, xhr) {
			let {
				responseType
			} = this.options;

			let response = {
				status: xhr.status,
				statusText: xhr.statusText,
				data: {},
				headers: {},
				config: this.options,
				request: xhr
			};

			// 获取响应头信息
			let allHeaders = xhr.getAllResponseHeaders();
			allHeaders = allHeaders.split(/(?:\n)/);
			allHeaders.forEach(item => {
				if (!item) return;
				let [key, value] = item.split(': ');
				response.headers[key] = value;
			});

			if (lx === 0) {
				// 把从服务器获取的结果变为responseType指定的数据格式
				switch (responseType.toLowerCase()) {
					case 'json':
						response.data = JSON.parse(xhr.responseText);
						break;
					case 'text':
						response.data = xhr.responseText;
						break;
					case 'document':
						response.data = xhr.responseXML;
						break;
					case 'arraybuffer':
					case 'blob':
					case 'stream':
						response.data = xhr.response;
						break;
					default:
						response.data = xhr.responseText;
				}
				return response;
			}

			// 失败
			return {
				config: this.options,
				request: xhr,
				message: xhr.responseText,
				response
			};
		}
	}

	/* 提供供外面调用的_ajax方法 */
	// 把用户传递的配置项和默认配置项进行合并处理
	function _initDefaults(options) {
		// HEADERS的特殊处理
		let headers = options.headers;
		if (headers && typeof headers === "object") {
			_ajax.defaults.headers = Object.assign(
				_ajax.defaults.headers,
				headers
			);
			delete options.headers;
		}
		return Object.assign(_ajax.defaults, options);
	}

	function _ajax(options = {}) {
		options = _initDefaults(options);
		return new MyAJAX(options);
	}

	// 默认的配置项
	_ajax.defaults = {
		url: '',
		baseURL: '',
		method: 'get',
		// GET系列请求传递参数
		params: {},
		// POST系列请求：配置默认传递给服务器的数据格式是JSON格式
		data: {},
		transformRequest: data => {
			if (data !== null && typeof data === "object") {
				return JSON.stringify(data);
			}
			return data;
		},
		// 自定义请求头信息
		headers: {
			"Content-Type": "application/json;charset=UTF-8"
		},
		timeout: 0,
		withCredentials: false,
		responseType: 'json',
		validateStatus: status => (status >= 200 && status < 300)
	};

	// 还需要提供一些快捷方法 _ajax.get/post/all/interceptors...
	["get", "delete", "head", "options"].forEach(name => {
		_ajax[name] = function (url, options = {}) {
			options.method = name;
			options.url = url;
			options = _initDefaults(options);
			return new MyAJAX(options);
		};
	});

	["post", "put"].forEach(name => {
		_ajax[name] = function (url, data = {}, options = {}) {
			options.method = name;
			options.url = url;
			options.data = data;
			options = _initDefaults(options);
			return new MyAJAX(options);
		};
	});

	// all方法
	_ajax.all = function all(arr = []) {
		return Promise.all(arr);
	};

	// 拦截器
	function _use(...funcs) {
		// this : request/response
		// 如果没有传递函数（成功/失败处理）,我们给一个默认值
		function interceptorsA(response) {
			// response：对于请求拦截器来讲就是config
			return response;
		}

		function interceptorsB(reason) {
			return Promise.reject(reason);
		}

		funcs.length === 0 ? funcs = [interceptorsA, interceptorsB] : null;
		funcs.length === 1 ? funcs = [funcs[0], interceptorsB] : null;

		this.push(...funcs);
	}
	_ajax.interceptors = {
		request: [],
		response: []
	};
	_ajax.interceptors.request.use = _use;
	_ajax.interceptors.response.use = _use;


	// 暴露到全局供其使用
	window._ajax = _ajax;

	// 想让其支持ES6Module模块导入（基于CommonJS导出，也可以基于ES6Module导入）
	if (typeof module === "object" && typeof module.exports === "object") {
		module.exports = _ajax;
	}
})();